export const config = {
    url:{
        products:'https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master/mobiles.json'
    }
}