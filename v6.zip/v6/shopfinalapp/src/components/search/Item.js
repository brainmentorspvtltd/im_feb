import React from 'react';


export const Item=(props)=> {
    let item = props.item;
    const imgStyle = {
        width:'100px',
        height:'100px'
    };
    return (
        <>
                 <img style={imgStyle} src={item.url}/>
                        <p>{item.name}</p>
                        <p>{item.price.toLocaleString('hi-IN')}</p>
                        <p>{item.id}</p>
        </>
    )
}
