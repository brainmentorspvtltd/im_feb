import React from 'react';
import { Item } from './Item';
export const Items = (props)=>{

    return (
        <div>
            {props.items.map(item=>{
                return (
                    <div>
                       <Item item={item}/>
                    </div>
                )
            })}
        </div>
    )
}