import React, { useRef } from 'react';
export const Search=(props)=>{
    const searchVal = useRef('');
    const takeSearchVal=()=>{
        let searchValue = searchVal.current.value;
        props.getSearchValue(searchValue);
    }
    return (
        <>
        <div className='form-group'>
            <label>Search Item</label>
            <input ref={searchVal} className='form-control' type='text' placeholder='Type to Search'/>
        </div>
        <br/>
        <div className='form-group'>
            <button onClick={takeSearchVal} className='btn btn-primary'>Search</button>
        </div>
        </>
    )
}