module.exports =  route = (request, response)=>{
if(request.url == '/home'){

    // for(let  i = 1;i<=1000000; i++){
    //     for(let j= 1; j<=100000; j++){

    //     }
    // }
    response.write('Welcome Home');
    response.end();
}
else
if(request.method == 'GET' && request.url.includes('/search')){
    const url = require('url');
    const obj = url.parse(request.url,true);
    const price = obj.query.price;
    const productApi = require('../api/productsapi');
    const promise = productApi();
    promise.then(data=>{
        data = data.toString();
        console.log('DATA is ',data);
        data = JSON.parse(data);
        const filteredRecords = data['mobiles'].filter(mobile=>mobile.price>price);
        const json = JSON.stringify({"mobiles":filteredRecords});
        response.write(json);
        response.end();
    }).catch(err=>{
        console.log('Server Error in Search ',err);
    });
}
else
if(request.url=='/products'){
    //response.write('Welcome Search');
    const productApi = require('../api/productsapi');
    const promise = productApi();
    promise.then(data=>response.write(data.toString()))
    .catch(err=>{
        console.log(err);
        response.write('API Fails');
}).finally(()=>response.end());

}
else
if(request.url =='/about'){
    response.write('Welcome About');
    response.end();
}
else{
    response.write('OOPS U Type Some Wrong URL');
    response.end();
}

}