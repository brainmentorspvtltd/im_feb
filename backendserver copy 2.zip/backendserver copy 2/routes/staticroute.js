module.exports = (url, response)=>{
    const staticContent = [".html",".css",".js",".jpeg",".ico",".json",".png",".txt",".map"];
    const fs = require('fs');
    const path = require('path');
    if(url=='/'){
        url ='/index.html';
    }
    const fullPath = path.join( path.normalize(__dirname+"/..")+"/public"+url);
    console.log(fullPath);
    let extension = path.extname(fullPath);
    console.log(extension);

    if(staticContent.indexOf(extension)==-1){
        return false;
    }
    const readStream = fs.createReadStream(fullPath);
    readStream.pipe(response);
    return true;
}

