module.exports =  route = (request, response)=>{
if(request.url == '/home'){

    // for(let  i = 1;i<=1000000; i++){
    //     for(let j= 1; j<=100000; j++){

    //     }
    // }
    response.write('Welcome Home');
    response.end();
}
else
if(request.url=='/products'){
    //response.write('Welcome Search');
    const productApi = require('../api/productsapi');
    const promise = productApi();
    promise.then(data=>response.write(data.toString()))
    .catch(err=>{
        console.log(err);
        response.write('API Fails');
}).finally(()=>response.end());

}
else
if(request.url =='/about'){
    response.write('Welcome About');
    response.end();
}
else{
    response.write('OOPS U Type Some Wrong URL');
    response.end();
}

}