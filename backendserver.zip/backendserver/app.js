const http = require('http');
const route = require('./routes/route');
const staticContent = require('./routes/staticroute');
const handleRequestResponse=(request, response)=>{
    //console.log('Server Request');
    console.log('Server request ',request.url);
    if(staticContent(request.url,response)){
      return ;
    }
    route(request, response);
    // response.write('Hello Client');
    // response.end();
}
const server = http.createServer(handleRequestResponse);
const serverConfig = server.listen(  4321,()=>{
    console.log('...Server Started...',serverConfig.address().port);
})

