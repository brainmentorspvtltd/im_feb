const readAllProducts = ()=>{
const fs = require('fs');
const path = require('path');
const jsonPath = path.join(path.normalize(__dirname+'/..')+'/db/products.json');

const promise = new Promise((resolve, reject)=>{
    fs.readFile(jsonPath, (err,content)=>{
        if(err){
            reject(err);
        }
        else{
            resolve(content);
        }
    });
});
return promise;
}
module.exports = readAllProducts;