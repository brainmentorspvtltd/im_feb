export const config = {
    'ADD':'+',
    'SUBTRACT':'-'
}