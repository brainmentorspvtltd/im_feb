import React, { useRef } from 'react'
import { CalcAction } from '../actions/CalcAction';
import { store } from '../models/centralstore';
import { config } from '../utils/config';

export const Input=(props)=> {
    const fno = useRef('0');
    const sno = useRef('0');

    const doOperation=()=>{
        let firstNumber = fno.current.value;
        let secondnumber = sno.current.value;
        let type = config.ADD;
        const action = CalcAction(firstNumber,secondnumber,type);
        store.dispatch(action);
    }

    return (
        <>
           <label>First No</label>
           <input ref={fno} type='text' placeholder='Type First Number'/>
            <br/>
            <label>Second No</label>
           <input ref={sno} type='text' placeholder='Type Second Number'/>
            <button onClick={doOperation}>Add</button>
        </>
    )
}
