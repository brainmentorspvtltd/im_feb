import React from 'react'

export const Operations=(props)=> {


    return (
        <>

        </>
    )
}
