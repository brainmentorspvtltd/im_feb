import React from 'react'
import { Calc } from './containers/Calc'

 const App=(props)=> {


  return (
    <>
        <h1>React Redux Demo</h1>
        <Calc/>

    </>
  )
}
export default App;
