import React from 'react'
import { Input } from '../components/Input'
import  Output  from '../components/Output'

export const Calc=(props)=> {


    return (
        <>
          <h2>Calc App</h2>
          <Input/>
          <Output/>

        </>
    )
}
