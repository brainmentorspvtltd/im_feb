import {createStore} from 'redux';
import { CalcReducer } from './calcreducer';
export const store = createStore(CalcReducer);
store.subscribe(()=>{
    console.log("Changes Happen ",store);
})
