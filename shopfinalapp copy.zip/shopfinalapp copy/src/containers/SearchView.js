import React from 'react';
import { Cart } from '../components/search/Cart';
import { Items } from '../components/search/Items';
import { Search } from '../components/search/Search';
import { Loading } from '../components/ui/Loading';
import { ItemOperations } from '../models/ItemOperations';
import {ajax} from '../utils/ajax';
import { CartContext } from '../utils/cartcontext';
export class SearchView extends React.PureComponent{

//React.Component{

    constructor(props){
        super(props);
        this.searchValue = '';
        this.state = {items:[],count:0};
        console.log('Search view cons');
        this.t1  = React.createRef();
        this.totalItemInCart = 0;

    }

    /*
    shouldComponentUpdate(nextProps){
        if(this.props.x == nextProps.x){
            return false;
        }
        return true;
    }*/

    componentDidMount(){

        console.log('Search view componentDidMount');
        const promise = ajax();
        promise.then(response=>{
            console.log('Data Rec ',response);
            let items= ItemOperations.fillItems(response.data.mobiles);
            this.setState({items:items, count:items.length});
        }).catch(err=>console.log(err));
    }
    getSearchValue(searchValue){
        this.searchValue = searchValue;
    }
    takeValue(){
        //let myValue = this.refs.t1.value;
        let myValue = this.t1.current.value;
        console.log('MY Value is ',myValue);
    }
    setInCart(cartTotal){
        this.totalItemInCart = cartTotal;
        this.setState({...this.state});
    }
    getSearchByPriceResult(items){
        this.setState({items:items,count:items.length});
    }
    render(){
        console.log('Search view render');
        if(this.state.items.length==0){
            return (<Loading/>);
        }

        return (
            <>
            <CartContext.Provider value={{totalItemsInCart:this.totalItemInCart,setItemInCart:this.setInCart.bind(this)}}>
            <p>Ref Example</p>
            {/* OLD REF <input  type='text' ref='t1' placeholder='Type Name'/> */}
            <input  type='text' ref={this.t1} placeholder='Type Name'/>
            <button  onClick={this.takeValue.bind(this)}>Get Ref Value</button>
            <br/>
            <hr/>
            <Cart/>
            <Search getSearchByPriceResult={this.getSearchByPriceResult.bind(this)} getSearchValue={(searchValue)=>this.getSearchValue(searchValue)}/>
            <Items items = {this.state.items}/>
            </CartContext.Provider>
            </>
        );
    }
}