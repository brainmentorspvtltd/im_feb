import React from 'react'

export const About=(props)=> {

    console.log(props);
    return (
        <>
            <h1>I am About {props.match.params.name} {props.match.params.age} </h1>
        </>
    )
}
