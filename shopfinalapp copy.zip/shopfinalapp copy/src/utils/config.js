export const config = {
    url:{
        products:'http://localhost:4321/products',
        search:'http://localhost:4321/search'
    }
}