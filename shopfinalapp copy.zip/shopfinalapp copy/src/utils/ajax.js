import  axios from 'axios';
import { config } from './config';


export const searchProductAjax = (price)=>{
    const promise =  axios.get(config.url.search+"?price="+price,
    //{
        //params:{price:price}
    //}
    );
    //const promise = axios.post(config.url.products,{'pnamee:'Apple'});
    return promise;
    // return axios({
    //     method:'get',
    //     url:config.url.products,
    //     timeout:4000,
    //     maxContentLength:20000,
    //     // Post data
    //     // data:{
    //     //     'pname':'Apple Iphone'
    //     // }

    // });
}

export const ajax = ()=>{
    const promise =  axios.get(config.url.products);
    //const promise = axios.post(config.url.products,{'pnamee:'Apple'});
    return promise;
    // return axios({
    //     method:'get',
    //     url:config.url.products,
    //     timeout:4000,
    //     maxContentLength:20000,
    //     // Post data
    //     // data:{
    //     //     'pname':'Apple Iphone'
    //     // }

    // });
}


