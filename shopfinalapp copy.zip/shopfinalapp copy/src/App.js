import React from 'react';
import { Shop } from './containers/Shop';
const App = (props)=>{
  return (<div className='container'>
    <Shop shopname='ABC Shop'/>
  </div>);
}
export default App;