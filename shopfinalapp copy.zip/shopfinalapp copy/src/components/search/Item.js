import React, { useState } from 'react';
import { ItemOperations } from '../../models/ItemOperations';
import { CartContext } from '../../utils/cartcontext';


export const Item=(props)=> {
    console.log('Item  Render Call');
    let item = props.item;
    const [isAdded,setAdded] = useState(false);
    const imgStyle = {
        width:'100px',
        height:'100px'
    };
    const toggleAdd= ()=>{
        item.toggle();
        setAdded(item.isAdded);
    }
    return (
        <>
            <CartContext.Consumer>{
                value=>{
                    return(
                        <>
                        <img style={imgStyle} src={item.url}/>
                        <p>{item.name}</p>
                        <p>{item.price.toLocaleString('hi-IN')}</p>
                        <p>{item.id}</p>

                        <button className='btn btn-success' onClick={()=>{
                            toggleAdd();
                            value.setItemInCart(ItemOperations.countInCart());

                        }}>{item.isAdded?'Remove From Cart':'Add to Cart'}</button>
                        </>
                    );
                }
                }

            </CartContext.Consumer>
        </>
    )
}
