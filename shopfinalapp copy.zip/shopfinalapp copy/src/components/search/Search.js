import React, { useEffect, useRef } from 'react';
import { searchProductAjax } from '../../utils/ajax';
export const Search=React.memo((props)=>{
    const searchVal = useRef('');
    // useEffect(()=>{
    //     // ComponentDidMount, ComponentDidUpdate
    //     console.log('Use Effect.....');
    // },[x,y]);
    const takeSearchVal=()=>{
        let searchValue = searchVal.current.value;
        const promise = searchProductAjax(searchValue);
        promise.then(response=>{
            console.log('DATA IS ',response);

            props.getSearchByPriceResult(response['data']['mobiles']);
        }).catch(err=>{
            console.log('Search Product Error ',err);
        })
        props.getSearchValue(searchValue);
    }
    return (
        <>
        <div className='form-group'>
            <label>Search Item</label>
            <input ref={searchVal} className='form-control' type='text' placeholder='Type to Search'/>
        </div>
        <br/>
        <div className='form-group'>
            <button onClick={takeSearchVal} className='btn btn-primary'>Search</button>
        </div>
        </>
    )
});