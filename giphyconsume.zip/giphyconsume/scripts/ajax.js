function old(){

    doAjax(callBackFn);
}

function doAjax(fn){
    var xmlHttpRequest = new window.XMLHttpRequest();
    xmlHttpRequest.onreadystatechange=function(){
    if(xmlHttpRequest.readyState==4 && xmlHttpRequest.status==200){
    console.log('Before return ',xmlHttpRequest.readyState);
    fn (xmlHttpRequest.responseText);
    }

    }
    xmlHttpRequest.open('GET','https://media3.giphy.com/media/l3975CZuyQgoNVuOA/giphy.gif',true);
    xmlHttpRequest.send(null);
    }
    // function callMeBack(data){
    // console.log('Data Rec ',data);
    // }
    // console.log("First ");
    // doAjax(callMeBack);
    // console.log("Second ",json);
function newWay(){
    var promise = fetch('https://api.giphy.com/v1/gifs/search?api_key=vFRSFWo6g7vJ7ZAjt3DMDolU52ORTxwH&q=Iron%20Man&limit=5');
promise.then(response=>response.json().then(jsonData=>console.log(jsonData)).catch(e=>console.log('Error in JSON ',e)) ).catch(err=>console.log(err));
}