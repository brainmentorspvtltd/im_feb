// Structure of Expense
/*function Expense(id, name, cost, remarks, url){
    //var this = {}; // Object Literal
    this.id = id;
    this.name = name;
    this.cost = cost;
    this.remarks = remarks;
    this.url = url;
    //return this;
    }*/
    // Expense.prototype.toggle= function(){

    // }

    class Expense{
        constructor(id=0, name='', cost=0, remarks='', url=''){
        this.id = id;
        this.name = name;
        this.cost = cost;
        this.remarks = remarks;
        this.url = url;
        this.isMarked = false;
        }
        toggle(){
            this.isMarked = !this.isMarked;
        }
        }