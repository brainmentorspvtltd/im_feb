// CRUD
const expenseOperations = {
    // add:function(){

    // }
    isAsc:true,
    expenses:[],
    add(expenseObj){
        let expense = new Expense();
        for(let key in expenseObj){
            expense[key]  = expenseObj[key];
        }
        this.expenses.push(expense);

    },
    searchById(id){
        return this.expenses.find(expense=>expense.id==id);
    },
    getTotal(){
        return this.expenses.length;
    },
    toggleMark(id){
        let expenseObject = this.searchById(id);
        if(expenseObject){
            expenseObject.toggle();
        }
    },
    remove(){
        this.expenses = this.expenses.filter(expense=>!expense.isMarked);
        return this.expenses;
    },
    search(){

    },
    update(){

    },
    sort(){
        if(this.isAsc){
            this.expenses.sort((first, second)=>first.cost-second.cost);
        }
        else{
            this.expenses.sort((first, second)=>second.cost-first.cost);
        }
        this.isAsc = !this.isAsc;
    },
    countMark(){
        return this.expenses.filter(expense=>expense.isMarked).length;
    },
    countUnMark(){
        return this.getTotal() - this.countMark();
    }

}