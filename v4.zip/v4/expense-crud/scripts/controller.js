// DOM, BOM
//bindEvents();
window.addEventListener('load',init);
function init(){
    bindEvents();
    updateCounts();
}
function bindEvents(){
    document.querySelector('#add').addEventListener('click',add);
    document.querySelector('#remove').addEventListener('click',deleteMarked);
    document.querySelector('#save').addEventListener('click',save);
    document.querySelector('#load').addEventListener('click',load);
    document.querySelector('#sort').addEventListener('click',sort);
    document.querySelector('#update').addEventListener('click',update);
    // let addButton = document.querySelector('#add');
    // addButton.addEventListener('click',add);
}

function update(){
    const obj = readDOM();
    const currentRowObject = expenseOperations.searchById(obj.id);
    for(let key in obj){
        currentRowObject[key] = obj[key];
    }
    printExpenses(expenseOperations.expenses);

}

const sort = ()=>{
    expenseOperations.sort();
    printExpenses(expenseOperations.expenses);
}

const save = ()=>{
    if(window.localStorage){
        let json = JSON.stringify(expenseOperations.expenses);
        console.log('JSON is ',json, typeof json);
        console.log('Normal Object is ',expenseOperations.expenses, typeof expenseOperations.expenses);
        localStorage.exp = json;
        alert('Data Saved....');
    }
    else{
        alert("Outdated Browser No LocalStorage");
    }
}

const load = ()=>{
    if(window.localStorage){
        if(localStorage.exp){
            let expenses = JSON.parse(localStorage.exp);
            expenseOperations.expenses = expenses;
            printExpenses(expenses);
            updateCounts();
        }
        else{
            alert("No Data to Load.....");
        }
    }
    else{
        alert("Outdated Browser No LocalStorage");
    }
}

function deleteMarked(){
    let expenses = expenseOperations.remove();
    printExpenses(expenses);
    updateCounts();

}
function printExpenses(expenses){
    document.querySelector('#expenses').innerHTML = '';
    expenses.forEach(printExpense);
}

function add(){
    let obj = readDOM();
    expenseOperations.add(obj);
    printExpense(obj);
    updateCounts();
}

function toggleMark(){
console.log('Mark Toggle ',this);
let id = this.getAttribute('eid');
expenseOperations.toggleMark(id);
let tr = this.parentNode.parentNode;
//tr.className = 'alert-danger';
tr.classList.toggle('alert-danger');
updateCounts();
//expenseOperations.toggleMark(ID?);
}
function edit(){
console.log('Edit...',this);
let id = this.getAttribute('eid');
const currentRowObject = expenseOperations.searchById(id);
printFields(currentRowObject);
}

function printFields(currentRowObject){
    for(let key in currentRowObject){
        if(key=='isMarked'){
            continue;
        }
        document.querySelector(`#${key}`).value = currentRowObject[key];
    }
}

function createIcon(className, fn, id){
    let icon = document.createElement('i');
    //icon.src = path;
    icon.className = 'icons mr-2 '+className;
    icon.addEventListener('click',fn);
    icon.setAttribute('eid',id);
    //icon.className = className;
   // <i class="fas fa-edit"></i>
    return icon;
}

function readDOM(){
    let id = document.querySelector('#id').value;
    let name = document.querySelector('#name').value;
    let cost = document.querySelector('#cost').value;
    let remarks = document.querySelector('#remarks').value;
    let url = document.querySelector('#url').value;
    console.log(id, name, cost, remarks, url);
    return {id, name, cost, remarks, url};

}

function updateCounts(){
    document.querySelector('#total').innerText = expenseOperations.getTotal();
    document.querySelector('#mark').innerText = expenseOperations.countMark();
    document.querySelector('#unmark').innerText=expenseOperations.countUnMark();
}

function printExpense(expenseObj){
    let tbody = document.querySelector('#expenses');
    let tr = tbody.insertRow();
    let index = 0;
    for(let key in expenseObj){
        if(key=='isMarked'){
            continue;
        }
    let td = tr.insertCell(index);
    td.innerText = expenseObj[key];
    index++;
    }
    let td= tr.insertCell(index);
    td.appendChild(createIcon(constants.icons.trash, toggleMark,expenseObj.id));
    td.appendChild(createIcon(constants.icons.edit, edit,expenseObj.id));


}