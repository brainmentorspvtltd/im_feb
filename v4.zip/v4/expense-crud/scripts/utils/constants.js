const constants = {
    icons:{
        trash:'fas fa-trash',
        edit:'fas fa-edit'
        //trash:'https://i.pinimg.com/originals/9e/00/bf/9e00bf1f81a6317ced3c67c681aa5017.png',
        //edit:'https://img.icons8.com/cotton/2x/edit.png'
    }
}