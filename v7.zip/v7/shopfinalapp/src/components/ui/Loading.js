import React from 'react';
export const Loading = (props)=>{
    return (<img src='https://thumbs.gfycat.com/MadeupWillingKronosaurus-max-1mb.gif'/>);
}