import React, { useState } from 'react';


export const Item=(props)=> {
    console.log('Item  Render Call');
    let item = props.item;
    const [isAdded,setAdded] = useState(false);
    const imgStyle = {
        width:'100px',
        height:'100px'
    };
    const toggleAdd= ()=>{
        item.toggle();
        setAdded(item.isAdded);
    }
    return (
        <>
                 <img style={imgStyle} src={item.url}/>
                        <p>{item.name}</p>
                        <p>{item.price.toLocaleString('hi-IN')}</p>
                        <p>{item.id}</p>

                        <button className='btn btn-success' onClick={toggleAdd}>{item.isAdded?'Remove From Cart':'Add to Cart'}</button>
        </>
    )
}
