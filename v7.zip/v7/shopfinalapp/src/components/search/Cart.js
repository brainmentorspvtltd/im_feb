import React from 'react'

export const Cart=(props)=> {


    return (

          <p>Items in Cart {props.cartTotal}</p>

    )
}
