import { ItemModel } from "./ItemModel";

export const ItemOperations = {
    items:[],
    fillItems(items){
        items.forEach(item=>{
            let itemObject = new ItemModel(item.id, item.name, item.price, item.url);
            this.items.push(itemObject);
        });
        return this.items;
    }
}