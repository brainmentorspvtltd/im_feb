import React from 'react';
import { SearchView } from './SearchView';
export const Shop = (props)=>{
    return (
        <>
            <h1 className='alert-info text-center'>Shop App</h1>
            <SearchView/>
        </>
    );

}