console.log(process.cwd());
process.on('uncaughtException',(err)=>{
    console.log('Caught It ',err);
    // Mail
});
var key = process.argv[2];
const config = require('./env');
const dbHost = config[key].db.host;
console.log('IP for ',dbHost, 'Env ',key);
// try{
// abcd();
// }
// catch(e){
//     console.log('Catch ',e);
// }