
// module.exports = function add(a,b){

//     var c= a + b;
//     //console.log(c);
//     return c;
// }
// module.exports.add = function add(a,b){

//     var c= a + b;
//     //console.log(c);
//     return c;
// }
const calc = {
    add(x,y){
       const sub = require('./two');
        return x + y +  sub(x,y);
    }
}
module.exports = calc;


