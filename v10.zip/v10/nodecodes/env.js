module.exports =  env ={
    'qct':{
        db:{
            host:'10.1.10.1',
            port:3306
        }
    },
    'sit':{
        db:{
            host:'10.1.20.1',
            port:3306
        }
    }
}