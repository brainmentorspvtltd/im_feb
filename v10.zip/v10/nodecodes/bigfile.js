const path ="/Users/amit/Documents/im-feb/ecma2021.mp4";
const fs = require('fs');
//fs.rename
//fs.copyFile
//fs.unlink
//fs.readdir
//fs.fstat
//fs.mkdir


// fs.readFile(path,(err,content)=>{
//     if(err){
//         console.log('Error');
//     }
//     else{
//         console.log('Done...');
//     }
// })
//const rstream = fs.createReadStream(path,{highWaterMark:20});
const rstream = fs.createReadStream(path);
const wstream = fs.createWriteStream('/Users/amit/Documents/im-feb/ecma2021-copy.mp4');
// rstream.on('data',(chunk)=>{
//     //console.log(chunk);
//     wstream.write(chunk);
// });
// rstream.on('end',()=>{
//     console.log('Copy End...');
// })
// rstream.on('error',()=>{

// })
rstream.pipe(wstream);