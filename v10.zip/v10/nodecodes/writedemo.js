const fs = require('fs');
const path = require('path');
const fullPath = path.join(__dirname+'/x.txt');
console.log('START....');
const content = fs.readFileSync(__filename);
console.log(content.toString());
console.log('--------- END ---------');
if(fs.existsSync(fullPath)){
    fs.appendFile(fullPath,"this is new data",(err)=>{
        if(err){
            console.log('Error in Append');
        }
        else{
            console.log('Append Done...');
        }
    })
}
else{
fs.writeFile(fullPath,"Hello This is Test....",(err)=>{
    if(err){
        console.log('Not Able to Write...');
    }
    else{
        console.log('Done...');
    }
});

}