const fs = require('fs');
console.log('I am watching...');
fs.watchFile('/Users/amit/Documents/im-feb/nodecodes/score.txt',(current, prev)=>{
    console.log('File Change Happen....');
    let content = fs.readFileSync('/Users/amit/Documents/im-feb/nodecodes/score.txt');
    console.log(content.toString());
})