const express = require('express');
const app = express();
app.use(express.static('public'));
app.use('/',require('./routes/route'));
app.listen(1111,()=>{
    console.log('Server Start');
});
