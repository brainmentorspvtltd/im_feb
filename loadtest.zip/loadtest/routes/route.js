const express = require('express');
const route = express.Router();
route.get('/home',(request, response)=>{
    for(let i = 1; i<=100000; i++){
        for(let j = 1; j<=100000; j++){

        }
    }
    response.send('Hello Home');
});
route.get('/about',(request, response)=>{
    response.send('Hello About');
});
route.get('/search',(request, response)=>{
    response.send('Hello Search');
});
module.exports = route;