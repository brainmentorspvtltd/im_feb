import React, { Component } from 'react';
import { Three } from './Three';

// Class Based Component / Old (Smart Component)
//React.Component{
export class One extends Component{
    constructor(props){
        super();
        this.count = 0;
        this.state = {counter:this.count};

    }
    increaseCount(event){
        console.log('Call Increase Count ',this.count);
        this.count++;
        this.setState({counter:this.count});
        // this.counter++;
    }

    giveMeChildValue(cubeValue){
        console.log('CubeValue is ',cubeValue);
        this.setState({counter:cubeValue});
    }

    render(){
        console.log('Render Call');
        return (
            <div>
                <Three callme={this.giveMeChildValue.bind(this)} val={this.state.counter}/>
                <button onClick={this.increaseCount.bind(this)}>Plus Count</button>
                <h1> I am a Smart Component {this.props.myvalue} {this.props.message}</h1>
                <p>Count Down {this.state.counter}</p>
            </div>
        )
    }

}