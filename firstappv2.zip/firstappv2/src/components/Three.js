import React from 'react';
export const Three = (props)=>{

    const sendDataToParent= ()=>{
        console.log("Send....");
        props.callme(cube);
    }

    let cube = props.val ** 3;

    return (
        <div>
            <button onClick={sendDataToParent}>Send to Parent</button>
            <h4>I am Three Component {props.val}</h4>
        </div>
    )
}