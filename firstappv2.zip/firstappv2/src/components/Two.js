import React from 'react';
export const Two = (props)=>{

    return (<h1>I am the Second Component {props.val}</h1>)
}