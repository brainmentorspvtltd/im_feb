import React from 'react';
import {One} from './components/one';
import { Two } from './components/Two';
//export const App = ()=>{
  // Functional Component
const App = ()=>{
  let msg = 'Hello I am the Parent';
  const takeInput = (event)=>{
    console.log('Take Input Call ',event.target.value);
    msg = event.target.value;
  }
  let year = 2021;
console.log('I am in Rendering...');
return (<div><h1>Hello React JS {year} </h1><h2>Hi React JS</h2>
<input type='text' onChange={takeInput} placeholder='Type to share data to all childs'/>
<One myvalue={year} message = {msg}/>
<br/>
<Two val = {year}/>
</div>);
//return (<h1>Hello React</h1>);
//return React.createElement('h1',null,'Hello React 2021');
}
export default App;