import React from 'react';
import { Input } from '../components/Input';
import { Button } from '../components/Operations';
import { Output } from '../components/Output';
import { StateHook } from './StateHook';
export class Greet extends React.Component{
    constructor(){
        super();
        this.inputs = {};
        this.state = {msg:''};  // var [msg,setMsg] = useState('');
    }
    takeInput(key, value){
        this.inputs [key] = value;
        console.log(this.inputs);
        this.setState({msg:''});
    }
    printOutput(event){
        let message = 'Welcome ';
           for(let key in this.inputs){
                this.inputs[key] = this.initCap(this.inputs[key]);
                message += this.inputs[key] + " ";
           }

           this.setState({msg:message});
    }
    initCap(str){
        return str.charAt(0).toUpperCase() + str.substring(1).toLowerCase();
    }



    clearAll(){
        this.inputs={'fname':'','lname':''};
        this.setState({msg:''});
    }
    render(){
        return (
            <>
            <h1>Greet App</h1>
             <Input mydata={this.inputs} name="fname" input={this.takeInput.bind(this)} label="First Name" placeholder="Type First Name Here"/>
             <Input mydata={this.inputs} name="lname" input={this.takeInput.bind(this)} label="Last Name" placeholder="Type Last Name Here"/>
             <Button callback={this.printOutput.bind(this)} name="Greet"></Button>
             <Button callback={this.clearAll.bind(this)} name="Clear All"></Button>
             <Output result = {this.state.msg}/>
             <br/>
             <hr/>
             <StateHook/>
             </>
        );
    }
}