import React, { useState } from 'react';
export const StateHook = (props)=>{
    console.log('State Hook Render');
    let [counter , setCounter] = useState('0');
    //let counter = 0;
    const plus=()=>{
        counter++;
        console.log('Plus Called ',counter);
        setCounter(counter);
    }
    return (
        <>
        <h4>State Hook {counter}</h4>
        <button onClick={plus}>Plus</button>
        </>
    )
}