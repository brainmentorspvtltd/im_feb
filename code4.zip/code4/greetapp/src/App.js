import React from 'react';
import { Greet } from './containers/Greet';
const App = ()=>{
  return(<div>
    <Greet/>
  </div>);
}
export default App;