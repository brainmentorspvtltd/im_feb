import React from 'react';
export const Input = (props)=>{
    console.log('RENDER.....');
    //var val = '';
    const collectData = (event)=>{
        let val = event.target.value;
        props.input(props.name,val);
    }

    return (<div>
        <label>{props.label}</label>
        <input value={props.mydata[props.name]} type='text' onChange = {collectData} placeholder={props.placeholder}/>
    </div>)
}