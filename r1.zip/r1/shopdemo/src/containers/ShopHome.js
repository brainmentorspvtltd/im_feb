import { Header } from "../components/Header";

export const ShopHome = ()=>{
    return (
        <div>
            <Header/>
        </div>
    );

}