import React from 'react';
import { ShopHome } from './containers/ShopHome';
const App = ()=>{
  return (<div><ShopHome/></div>)
}
export default App;