import React, { Component } from 'react';

// Class Based Component / Old (Smart Component)
//React.Component{
export class One extends Component{
    constructor(){

    }
    render(){
        return (
            <div>
                <h1> I am a Smart Component</h1>
            </div>
        )
    }

}