import React from 'react';
import {One} from './components/one';
//export const App = ()=>{
  // Functional Component
const App = ()=>{
return (<div><h1>Hello React JS </h1><h2>Hi React JS</h2><One/></div>);
//return (<h1>Hello React</h1>);
//return React.createElement('h1',null,'Hello React 2021');
}
export default App;