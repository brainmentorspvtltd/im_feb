// DOM, BOM
//bindEvents();
window.addEventListener('load',init);
function init(){
    bindEvents();
    updateCounts();
}
function bindEvents(){
    document.querySelector('#add').addEventListener('click',add);
    // let addButton = document.querySelector('#add');
    // addButton.addEventListener('click',add);
}
function add(){
    let obj = readDOM();
    expenseOperations.add(obj);
    printExpense(obj);
    updateCounts();
}

function toggleMark(){
console.log('Mark Toggle ',this);
let tr = this.parentNode.parentNode;
//tr.className = 'alert-danger';
tr.classList.toggle('alert-danger');
}
function edit(){
console.log('Edit...',this);

}

function createIcon(className, fn){
    let icon = document.createElement('i');
    //icon.src = path;
    icon.className = 'icons mr-2 '+className;
    icon.addEventListener('click',fn);
    //icon.className = className;
   // <i class="fas fa-edit"></i>
    return icon;
}

function readDOM(){
    let id = document.querySelector('#id').value;
    let name = document.querySelector('#name').value;
    let cost = document.querySelector('#cost').value;
    let remarks = document.querySelector('#remarks').value;
    let url = document.querySelector('#url').value;
    console.log(id, name, cost, remarks, url);
    return {id, name, cost, remarks, url};

}

function updateCounts(){
    document.querySelector('#total').innerText = expenseOperations.getTotal();
}

function printExpense(expenseObj){
    let tbody = document.querySelector('#expenses');
    let tr = tbody.insertRow();
    let index = 0;
    for(let key in expenseObj){
    let td = tr.insertCell(index);
    td.innerText = expenseObj[key];
    index++;
    }
    let td= tr.insertCell(index);
    td.appendChild(createIcon(constants.icons.trash, toggleMark));
    td.appendChild(createIcon(constants.icons.edit, edit));


}