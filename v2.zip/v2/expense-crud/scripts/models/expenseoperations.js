// CRUD
const expenseOperations = {
    // add:function(){

    // }
    expenses:[],
    add(expenseObj){
        let expense = new Expense();
        for(let key in expenseObj){
            expense[key]  = expenseObj[key];
        }
        this.expenses.push(expense);

    },
    getTotal(){
        return this.expenses.length;
    },
    remove(){

    },
    search(){

    },
    update(){

    },
    sort(){

    },
    countMark(){

    },
    countUnMark(){

    }

}