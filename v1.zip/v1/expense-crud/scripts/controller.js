// DOM, BOM

function readDOM(){
    let id = document.querySelector('#id').value;
    let name = document.querySelector('#name').value;
    let cost = document.querySelector('#cost').value;
    let remarks = document.querySelector('#remarks').value;
    let url = document.querySelector('#url').value;
    console.log(id, name, cost, remarks, url);

}