import { ItemModel } from "./ItemModel";

export const ItemOperations = {
    items:[],
    countInCart(){
        return this.items.filter(item=>item.isAdded).length;
    },
    fillItems(items){
        this.items = [];
        items.forEach(item=>{
            let itemObject = new ItemModel(item.id, item.name, item.price, item.url);
            this.items.push(itemObject);
        });
        return this.items;
    }
}