import React from 'react'
import { CartContext } from '../../utils/cartcontext'

export const Cart=(props)=> {


    return (
          <>
          <CartContext.Consumer>{
            value=>{
                return ( <p>Items in Cart {value.totalItemsInCart}</p>);
            }
            }

          </CartContext.Consumer>
          </>

    )
}
