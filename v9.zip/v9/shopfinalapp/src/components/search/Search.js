import React, { useEffect, useRef } from 'react';
export const Search=React.memo((props)=>{
    const searchVal = useRef('');
    // useEffect(()=>{
    //     // ComponentDidMount, ComponentDidUpdate
    //     console.log('Use Effect.....');
    // },[x,y]);
    const takeSearchVal=()=>{
        let searchValue = searchVal.current.value;
        props.getSearchValue(searchValue);
    }
    return (
        <>
        <div className='form-group'>
            <label>Search Item</label>
            <input ref={searchVal} className='form-control' type='text' placeholder='Type to Search'/>
        </div>
        <br/>
        <div className='form-group'>
            <button onClick={takeSearchVal} className='btn btn-primary'>Search</button>
        </div>
        </>
    )
});