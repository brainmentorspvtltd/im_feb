import React from 'react';
import { Item } from './Item';
export const Items = (props)=>{

    return (
        <div>
            {props.items.map((item,index)=>{
                return (
                    <div key={index}>
                       <Item key={index} item={item}/>
                    </div>
                )
            })}
        </div>
    )
}