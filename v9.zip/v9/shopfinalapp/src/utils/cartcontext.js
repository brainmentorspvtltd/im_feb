import React from 'react';
export const CartContext =
React.createContext({totalItemsInCart:0,setItemInCart:function(){}});