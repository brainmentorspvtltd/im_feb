module.exports = {
    add(x,y){
        return x+y;
    },
    sub(x,y){
        return x-y;
    }
}