const obj = require('./index');
console.log(obj.add(10,20));