const obj = require('./one');
const chalk = require('chalk');
console.log(typeof obj);
let result = obj.add(10,20);
console.log(chalk.green(chalk.bold(result)));

// const fn = require('./one');
// console.log(typeof fn);
// console.log(fn(10,20));