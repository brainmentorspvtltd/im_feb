const fs = require('fs');
//const myPath = "/Users/amit/Documents/im-feb/nodecodes/readfile.js";
console.log('Before read ',process.env.UV_THREADPOOL_SIZE);
process.env.UV_THREADPOOL_SIZE=10;
console.log('Before read ',process.env.UV_THREADPOOL_SIZE);
fs.readFile(__filename,(err,content)=>{
    if(err){
        console.log('Error in File Read...');
    }
    else{
        console.log(content.toString());
    }
}); // async
const path = require('path');
const rootPath = path.normalize(__dirname+'/..');
console.log('Root Path is ',rootPath);
const fullPath = path.join(rootPath+'/a.txt');
//const fullPath = path.join(__dirname+'/two.js');
console.log('FullPath is ',fullPath);
fs.readFile(fullPath,(err,content)=>{
    if(err){
        console.log('Error in File Read...');
    }
    else{
        console.log(content.toString());
    }
});
console.log('after read');