import React from 'react';
import {connect} from 'react-redux';
export const Output=(props)=> {



    return (
        <>
            <p>Result is {props.result} </p>
        </>
    );
}
const mapReduxStateToProps = (state)=>{
    return {
        result:state.result
    };
}
export default connect(mapReduxStateToProps)(Output)
