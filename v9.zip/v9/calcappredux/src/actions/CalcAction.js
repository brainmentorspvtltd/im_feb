export const CalcAction = (firstNo, secondNo, type)=>{
    return {
        type:type,
        payload:{
            firstNumber:firstNo,
            secondNumber:secondNo
        }
    }
}