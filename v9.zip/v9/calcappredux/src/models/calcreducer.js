import { config } from "../utils/config";

export const CalcReducer = (state = {result:0},action)=>{
    if(action.type==config.ADD){
        let sum = parseInt(action.payload.firstNumber) + parseInt(action.payload.secondNumber);
        return {...state, result:sum};
    }
    else
    if(action.type == config.SUBTRACT){
        let sub = parseInt(action.payload.firstNumber) + parseInt(action.payload.secondNumber);
        return {...state, result:sub};
    }
    return state;
}