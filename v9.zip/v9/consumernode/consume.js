const mod = require('../nodecodes');
let result = mod.add(1000,20);
console.log('Result is ',result);