const obj = require('calcbrainmentors');
console.log(obj.add(10,20));